# FORGED Coaching — Website

Official website for **Forged Coaching** — strength, discipline, transformation.

- **Live domain:** https://forgedcoaching.us
- **Stack:** single self-contained `index.html` (HTML + CSS + JS, no build step)

## Editing
Open `index.html` in any editor. Everything (styles, scripts, brand assets) is inline,
so there is nothing to compile or install.

## Deploy
Hosted on Cloudflare Pages, connected to this GitHub repo.
Every push to `main` automatically publishes to https://forgedcoaching.us

Brand: Jet Black `#0D0D0D` · Forged Green `#0F2B1D` · Iron Green `#1F4A33` · Steel `#4B4B4B` · Asphalt `#A7A7A7`
Type: Bebas Neue (headlines) · Montserrat (body)
